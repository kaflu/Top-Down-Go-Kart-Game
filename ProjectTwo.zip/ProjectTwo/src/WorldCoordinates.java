
public class WorldCoordinates
{
	/** Reads in the format Point2D(posX, posY, orientation) */
	
	/** Kart Locations */
	public static Point2D Donkey   = new Point2D("donkey"  , 1332, 13086);
	public static Point2D Elephant = new Point2D("elephant", 1260, 13086);
	public static Point2D Dog      = new Point2D("dog"     , 1404, 13086);
	public static Point2D Octopus  = new Point2D("octopus" , 1476, 13086);
	
	/** Game messages */
	public static Point2D GameOver = new Point2D("Game Over Message", 250, 250);

	
	
	
}
