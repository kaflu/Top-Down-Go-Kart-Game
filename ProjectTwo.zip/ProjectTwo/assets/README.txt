The files included in this directory are derived from copyrighted works, but
distributed under permissive licenses. You may redistribute them, but only if
you agree to the license terms.

Karts: From Super Tux Kart
    http://supertuxkart.sourceforge.net/
    Donkey: Kinsu <kinsumail@gmail.com>
        (Creative Commons Attribution 3.0)
    Dog: Wolter Hellmund <wolterh6@gmail.com>
        (Creative Commons Attribution-ShareAlike 3.0)
    Others: No license file, but generally licensed under a permissive license
        (see http://supertuxkart.sourceforge.net/Licensing)
Terrain graphics: The Battle for Wesnoth
    (GNU General Public License, version 2 or later)
    http://wesnoth.org/
Tyre stack: Bridgestone Singapore
    (Creative Commons Attribution 3.0)
    http://www.mynewsdesk.com/sg/view/image/bridgestone-tyres-71466
Tomato: Soil-Net Library
    (Creative Commons Attribution-NonCommercial-ShareAlike 2.0)
    http://www.soil-net.com/album/Plants/Fruit_Veg/slides/FruitVeg%20Tomato%2004.html
Oil can: Culturally Authentic Pictorial Lexicon
    (Creative Commons Attribution-NonCommercial-ShareAlike 3.0 United States)
    http://capl.washjeff.edu/browseresults.php?langID=2&photoID=4486
Rocket: Oxygen icon set (rocket, 128x128)
    (GNU Lesser General Public License)
    http://www.mricons.com/icon/73708/128/launch-rocket
Oil slick: Matt Giuca
    (Creative Commons Attribution 3.0)
